# Level-up-bot

A motivational, micro-learning, and life-assistant Telegram bot built using Python and Firebase.

## Features

- Hustle tips
- Mood tracking
- Daily savings offers
- Life challenges

## Usage

1. Clone repo
2. Add your Telegram Bot Token in `bot.py`
3. Run the bot:
   ```
   python bot.py
   ```

## Dependencies

- pyTelegramBotAPI
- Firebase (for advanced use)
