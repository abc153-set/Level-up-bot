import telebot

# Replace with your bot token
TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def welcome(message):
    bot.send_message(message.chat.id, "Welcome to LevelUp Bot! Ready to level up your life?")

@bot.message_handler(func=lambda m: True)
def handle_all(message):
    bot.send_message(message.chat.id, f"You said: {message.text}")

bot.polling()
